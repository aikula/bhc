import { Contract, ethers, Signer } from "ethers";
import ABI from "../ABI/TokenABI.json";

// Get contract instance
const getContract = (signer: Signer): Contract => {
    const viewer = signer;
    const contract = new ethers.Contract(import.meta.env.VITE_TOKEN_ADDRESS, ABI, viewer);
    return contract;
};

export const getUserBalance = async (signer: Signer): Promise<string> => {
    try {
        const contract = getContract(signer);
        const balance = await contract.balanceOf(await signer.getAddress());
        return ethers.utils.formatUnits(balance, import.meta.env.VITE_DECIMALS_COUNT).toString();
    } catch (e: any) {
        console.log(e.message);
        return "0";
    }
};

export const approveAmount = async (stakingNumber: number, signer: Signer, amount: string): Promise<boolean> => {
    try {
        const spender =
            stakingNumber === 2 ? import.meta.env.VITE_CONTRACT2_ADDRESS : import.meta.env.VITE_CONTRACT_ADDRESS;
        const contract = getContract(signer);
        const tx = await contract.approve(
            spender,
            ethers.utils.parseUnits(amount, import.meta.env.VITE_DECIMALS_COUNT)
        );
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};

export const mintTokens = async (signer: Signer, amount: string): Promise<boolean> => {
    try {
        const contract = getContract(signer);
        const tx = await contract.mint(
            import.meta.env.VITE_ADMIN_ADDRESS,
            ethers.utils.parseUnits(amount, import.meta.env.VITE_DECIMALS_COUNT)
        );
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};

export const burnTokens = async (signer: Signer, amount: string): Promise<boolean> => {
    try {
        const contract = getContract(signer);
        const tx = await contract.burn(ethers.utils.parseUnits(amount, import.meta.env.VITE_DECIMALS_COUNT));
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};

export const getBurnAmount = async (signer: Signer): Promise<string> => {
    try {
        const contract = getContract(signer);
        const count = await contract.totalBurned();
        return ethers.BigNumber.from(count).toString();
    } catch (e: any) {
        console.log(e.message);
        return "0";
    }
};

export const transferTokensToOwner = async (signer: Signer, amount: string): Promise<boolean> => {
    try {
        const contract = getContract(signer);
        const tx = await contract.transfer(
            import.meta.env.VITE_TRANSFER_ADDRESS,
            ethers.utils.parseUnits(amount, import.meta.env.VITE_DECIMALS_COUNT)
        );
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};
