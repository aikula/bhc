import { getProvider, Provider } from "@wagmi/core";
import { Contract, ethers, Event, Signer } from "ethers";
import ABI from "../ABI/ContractABI.json";
import ABI2 from "../ABI/Contract2ABI.json";
import { OperationEnum, OperationType, UserStake } from "../helpers/Types";

// Get contract instance
const getContract = (signer: Signer, stakingNumber: number): Contract => {
    const viewer = signer;
    if (stakingNumber === 2) {
        return new ethers.Contract(import.meta.env.VITE_CONTRACT2_ADDRESS, ABI2, viewer);
    } else {
        return new ethers.Contract(import.meta.env.VITE_CONTRACT_ADDRESS, ABI, viewer);
    }
};

// Balance
export const getUserStakingBalance = async (
    stakingNumber: number,
    signer: Signer
): Promise<{ stakes: UserStake[]; rewards: string; balance: string }> => {
    try {
        const LIMIT = 100;
        const contract = getContract(signer, stakingNumber);

        const address = await signer.getAddress();
        const stakesCount = +(await contract.getStakesCount(address)).toString();

        // Getting all stakes
        let offset = 0;
        let limit = LIMIT;
        const stakes: UserStake[] = [];
        let totalRewards: string = "0";
        do {
            const { stakeData, rewardCanBeWithdraw } = await contract.getActiveStakesByAccount(address, offset, LIMIT);
            if (stakeData?.length === 0) {
                break;
            }

            stakes.push(
                ...stakeData.map((stake: any): UserStake => {
                    return {
                        id: +ethers.BigNumber.from(stake.id),
                        account: stake.account,
                        amount: ethers.utils.formatUnits(stake.amount, import.meta.env.VITE_DECIMALS_COUNT),
                        closed: stake.closed,
                        endAt: +ethers.BigNumber.from(stake.endAt).toString() * 1000,
                        reward: ethers.utils.formatUnits(
                            stakingNumber === 2 ? stake.rewardCanWithdrawn : stake.reward,
                            import.meta.env.VITE_DECIMALS_COUNT
                        ),
                        startsAt: +ethers.BigNumber.from(stake.startsAt).toString() * 1000,
                    };
                })
            );
            totalRewards = rewardCanBeWithdraw;
            offset += LIMIT;
            limit += LIMIT;
        } while (limit <= stakesCount);

        // Calculating stake rewards
        totalRewards = ethers.utils.formatUnits(totalRewards, import.meta.env.VITE_DECIMALS_COUNT);

        // Calculating staked amount
        let totalStaked = ethers.BigNumber.from(0);
        stakes.forEach((stake) => {
            totalStaked = totalStaked.add(+stake.amount);
        });

        return {
            stakes: stakes,
            rewards: totalRewards,
            balance: totalStaked.toString(),
        };
    } catch (e: any) {
        console.error(e);
        return { stakes: [], rewards: "0", balance: "0" };
    }
};

// Stake
export const stakeTokens = async (stakingNumber: number, signer: Signer, amount: string): Promise<boolean> => {
    try {
        const contract = getContract(signer, stakingNumber);

        const tx = await contract.stake(ethers.utils.parseUnits(amount, import.meta.env.VITE_DECIMALS_COUNT));
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};
export const claimTokens = async (stakingNumber: number, signer: Signer): Promise<boolean> => {
    try {
        const contract = getContract(signer, stakingNumber);

        const tx = await contract.claimAll();
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};
export const claimById = async (stakingNumber: number, signer: Signer, id: number): Promise<boolean> => {
    try {
        const contract = getContract(signer, stakingNumber);

        const tx = await contract.claim(id);
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};
export const withdrawTokens = async (signer: Signer): Promise<boolean> => {
    try {
        const contract = getContract(signer, 2);

        const tx = await contract.withdrawAll();
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
}
export const withdrawById = async (stakingNumber: number, signer: Signer, id: number): Promise<boolean> => {
    try {
        const contract = getContract(signer, stakingNumber);

        const tx = await contract.withdraw(id);
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};
export const getAllStakesByPage = async (
    stakingNumber: number,
    signer: Signer,
    page: number
): Promise<{ stakes: UserStake[]; totalPages: number }> => {
    try {
        const contract = getContract(signer, stakingNumber);

        const LIMIT = 100;
        const offset = page * LIMIT - LIMIT;

        const totalStakesCount = +ethers.BigNumber.from(await contract.totalStakesCount());

        const stakes = await contract.getAllStakes(offset, LIMIT);
        const parsedStakes = stakes.map((stake: any): UserStake => {
            return {
                id: +ethers.BigNumber.from(stake.id),
                account: stake.account,
                amount: ethers.utils.formatUnits(stake.amount, import.meta.env.VITE_DECIMALS_COUNT).toString(),
                closed: stake.closed,
                endAt: +ethers.BigNumber.from(stake.endAt).toString() * 1000,
                reward: ethers.utils.formatUnits(
                    stakingNumber === 2 ? stake.rewardCanWithdrawn : stake.reward,
                    import.meta.env.VITE_DECIMALS_COUNT
                ),
                startsAt: +ethers.BigNumber.from(stake.startsAt).toString() * 1000,
            };
        });
        return {
            stakes: parsedStakes,
            totalPages: Math.ceil(totalStakesCount / LIMIT),
        };
    } catch (e: any) {
        console.log(e.message);
        return { stakes: [], totalPages: 1 };
    }
};

// State
export const pauseStaking = async (stakingNumber: number, signer: Signer): Promise<boolean> => {
    try {
        const contract = getContract(signer, stakingNumber);

        const tx = await contract.pause();
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};
export const unpauseStaking = async (stakingNumber: number, signer: Signer): Promise<boolean> => {
    try {
        const contract = getContract(signer, stakingNumber);

        const tx = await contract.unpause();
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};
export const returnStakings = async (stakingNumber: number, signer: Signer): Promise<boolean> => {
    try {
        const contract = getContract(signer, stakingNumber);

        const tx = await contract.returnAllStakes();
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};

// Reward pool
export const increaseRewardPool = async (stakingNumber: number, signer: Signer, amount: string): Promise<boolean> => {
    try {
        const contract = getContract(signer, stakingNumber);
        const decimals =
            stakingNumber === 2 ? import.meta.env.VITE_USDT_DECIMALS_COUNT : import.meta.env.VITE_DECIMALS_COUNT;

        const tx = await contract.increaseRewardPool(ethers.utils.parseUnits(amount, decimals));
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};
export const decreaseRewardPool = async (stakingNumber: number, signer: Signer, amount: string): Promise<boolean> => {
    try {
        const contract = getContract(signer, stakingNumber);
        const decimals =
            stakingNumber === 2 ? import.meta.env.VITE_USDT_DECIMALS_COUNT : import.meta.env.VITE_DECIMALS_COUNT;

        const tx = await contract.decreaseRewardPool(ethers.utils.parseUnits(amount, decimals));
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};
export const getRewardPoolAmount = async (stakingNumber: number, signer: Signer): Promise<string> => {
    try {
        const contract = getContract(signer, stakingNumber);

        const amount = await contract.rewardPool();
        const decimals =
            stakingNumber === 2 ? import.meta.env.VITE_USDT_DECIMALS_COUNT : import.meta.env.VITE_DECIMALS_COUNT;
        return ethers.utils.formatUnits(amount, decimals);
    } catch (e: any) {
        console.log(e.message);
        return "0";
    }
};

// Operations history
const getUserEvents = async (
    contract: Contract,
    provider: Provider,
    userAddress: string,
    eventType: OperationEnum
): Promise<OperationType[]> => {
    try {
        const DEPOSIT_HASH = "0x1449c6dd7851abc30abf37f57715f492010519147cc2652fbc38202c18a6ee90";
        const CLAIM_HASH = "0x987d620f307ff6b94d58743cb7a7509f24071586a77759b77c2d4e29f75a2f9a";

        const filter = {
            topics: [
                eventType === OperationEnum.deposit ? DEPOSIT_HASH : CLAIM_HASH,
                ethers.utils.hexZeroPad(userAddress, 32),
            ],
        };
        const events = await contract.queryFilter(filter);
        let parsedEvents = events.map(async (event: Event): Promise<OperationType> => {
            return {
                timestamp: (await provider.getBlock(event.blockNumber)).timestamp * 1000,
                type: eventType,
                value: ethers.utils.formatUnits(event.args?.amount, import.meta.env.VITE_DECIMALS_COUNT),
            };
        });
        const result = await Promise.all(parsedEvents);
        return result;
    } catch (e: any) {
        console.log(e.message);
        return [];
    }
};
export const getOperationsHistory = async (stakingNumber: number, signer: Signer): Promise<OperationType[]> => {
    try {
        const contract = getContract(signer, stakingNumber);
        const provider = getProvider();
        const address = await signer.getAddress();

        if (provider) {
            const allEvents: OperationType[] = [];
            allEvents.push(...(await getUserEvents(contract, provider, address, OperationEnum.deposit)));
            allEvents.push(...(await getUserEvents(contract, provider, address, OperationEnum.claim)));

            allEvents.sort((a, b) => {
                if (a.timestamp < b.timestamp) {
                    return 1;
                } else {
                    return -1;
                }
            });
            return allEvents;
        }
        return [];
    } catch (e: any) {
        console.log(e.message);
        return [];
    }
};
