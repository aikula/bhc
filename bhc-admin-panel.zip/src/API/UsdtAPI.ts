import { Contract, ethers, Signer } from "ethers";
import ABI from "../ABI/UsdtABI.json";

// Get contract instance
const getContract = (signer: Signer): Contract => {
    const viewer = signer;
    const contract = new ethers.Contract(import.meta.env.VITE_USDT_ADDRESS, ABI, viewer);
    return contract;
};

export const approveUsdt = async (signer: Signer, amount: string): Promise<boolean> => {
    try {
        const contract = getContract(signer);
        const tx = await contract.approve(
            import.meta.env.VITE_CONTRACT2_ADDRESS,
            ethers.utils.parseUnits(amount, import.meta.env.VITE_USDT_DECIMALS_COUNT)
        );
        await tx.wait();
        return true;
    } catch (e: any) {
        console.log(e.message);
        return false;
    }
};