import "./NotFound.scss";
import { useContext } from "react";
import MainHeader from "../../components/Headers/MainHeader";
import Text from "../../languages.json";
import { Context } from "../../main";
import { observer } from "mobx-react-lite";

const NotFound = observer(() => {
    const {language} = useContext(Context);

    return (
        <>
            <MainHeader />
            <main className="notfound-container">
                <h1>404</h1>
				<p>{Text.notFound[language]}</p>
            </main>
        </>
    );
});

export default NotFound;
