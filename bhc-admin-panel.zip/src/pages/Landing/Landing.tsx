import ConnectButton from "../../components/ConnectButton/ConnectButton";
import LandingHeader from "../../components/Headers/LandingHeader";
import "./Landing.scss";
import Text from "../../languages.json";
import { useContext } from "react";
import { Context } from "../../main";
import { observer } from "mobx-react-lite";

const Landing = observer(() => {
    const { language } = useContext(Context);

    return (
        <>
            <LandingHeader />
            <main className="landing-container">
                <p>{Text.landing.text1[language]}</p>
                <p>{Text.landing.text2[language]}</p>

                <ConnectButton styles={{ marginTop: 40 }} />
            </main>
        </>
    );
});

export default Landing;
