import "./Tab.scss";
import { observer } from "mobx-react-lite";
import { useContext, useEffect } from "react";
import { useSigner } from "wagmi";
import { getUserBalance } from "../../../API/TokenAPI";
import { Context } from "../../../main";
import Text from "../../../languages.json";
import TransferComponent from "../../../components/TransferComponent/TransferComponent";

const Free = observer(() => {
    const { language, userStore } = useContext(Context);
    const { data: signer } = useSigner();

    const getBalance = async () => {
        if (signer) {
            const balance = await getUserBalance(signer);
            userStore.setBalance(balance);
        }
    };

    useEffect(() => {
        getBalance();
    }, [signer]);

    return (
        <div className="tab-container">
            <h3>{Text.freeTokens.heading[language]}</h3>
            <p>{userStore.balance} BHC</p>
            <TransferComponent />
        </div>
    );
});

export default Free;
