import { useContext, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useSigner } from "wagmi";
import {
    getOperationsHistory,
    getUserStakingBalance,
    claimTokens,
    claimById,
    withdrawTokens,
    withdrawById,
} from "../../../API/ContractAPI";
import Balance from "../../../components/Balance/Balance";
import OperationHistory from "../../../components/OperationHistory/OperationHistory";
import UserStakingsTable from "../../../components/StakingsTable/UserStakingsTable";
import { Context } from "../../../main";
import "./Tab.scss";

const Staking = () => {
    const { data: signer } = useSigner();
    const { userStore } = useContext(Context);
    const [depositModal, setDepositModal] = useState(false);

    // Getting stake number from url address
    const params = useParams();
    const stakeNumber = +(params.index ?? 1);

    const getBalance = async () => {
        if (signer) {
            const { stakes, rewards, balance } = await getUserStakingBalance(stakeNumber, signer);
            userStore.setStakedBalance(stakeNumber, balance);
            userStore.setStakedRewards(stakeNumber, rewards);
            userStore.setStakes(stakeNumber, stakes);
        }
    };

    const depositHandler = async () => {
        setDepositModal(true);
    };

    const claimHandler = async () => {
        if (signer) {
            const unstakeResult = await claimTokens(stakeNumber, signer);
            if (unstakeResult) {
                await updateInfo();
                alert("Successfully unstaked");
            } else {
                alert("Some error");
            }
        }
    };
    const claimByIdHandler = async (id: number) => {
        if (signer) {
            const result = await claimById(stakeNumber, signer, id);
            if (result) {
                await updateInfo();
                alert("Successfully unstaked");
            } else {
                alert("Some error");
            }
        }
    };

    const withdrawByIdHandler = async (id: number) => {
        if (signer) {
            const result = await withdrawById(stakeNumber, signer, id);
            if (result) {
                await updateInfo();
                alert("Successfully unstaked");
            } else {
                alert("Some error");
            }
        }
    };

    const updateOperationsHistory = async () => {
        if (signer) {
            const operations = await getOperationsHistory(stakeNumber, signer);
            userStore.setOperationsHistory(stakeNumber, operations);
        }
    };

    const updateInfo = async () => {
        await getBalance();
        await updateOperationsHistory();
    };

    useEffect(() => {
        if (!depositModal) {
            updateInfo();
        }
    }, [signer, depositModal, stakeNumber]);

    return (
        <div className="tab-container">
            <Balance
                stakeNumber={stakeNumber}
                depositHandler={depositHandler}
                claimHandler={claimHandler}
                depositModal={depositModal}
                setDepositModal={setDepositModal}
            />
            {stakeNumber === 2 ? (
                <UserStakingsTable stakeNumber={stakeNumber} closeStaking={withdrawByIdHandler} />
            ) : (
                <UserStakingsTable stakeNumber={stakeNumber} closeStaking={claimByIdHandler} />
            )}
            <OperationHistory stakeNumber={stakeNumber} />
        </div>
    );
};

export default Staking;
