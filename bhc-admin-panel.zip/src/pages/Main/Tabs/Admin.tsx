import "./Tab.scss";
import { useEffect, useState } from "react";
import { useSigner } from "wagmi";
import {
    decreaseRewardPool,
    getRewardPoolAmount,
    increaseRewardPool,
    pauseStaking,
    returnStakings,
    unpauseStaking,
} from "../../../API/ContractAPI";
import { approveAmount, burnTokens, getBurnAmount, mintTokens } from "../../../API/TokenAPI";
import StakingsTable from "../../../components/StakingsTable/StakingsTable";
import { approveUsdt } from "../../../API/UsdtAPI";

const Admin = () => {
    const { data: signer } = useSigner();
    const [rewardPoolAmount, setRewardPoolAmount] = useState("0");
    const [burnAmount, setBurnAmount] = useState("0");
    const [selectedStaking, setSelectedStaking] = useState(1);

    // Mint
    const mintHandler = async () => {
        const amount = (document.getElementById("mintAmount") as HTMLInputElement).value;

        if (signer && amount) {
            const result = await mintTokens(signer, amount);
            if (result) {
                alert("Successfully min");
            } else {
                alert("Some error");
            }
        }
    };

    // Burn amount
    const burnHandler = async () => {
        const amount = (document.getElementById("burnAmount") as HTMLInputElement).value;

        if (signer && amount) {
            const result = await burnTokens(signer, amount);
            if (result) {
                await updateBurnAmount();
                alert("Successfully burned");
            } else {
                alert("Some error");
            }
        }
    };
    const updateBurnAmount = async () => {
        if (signer) {
            const amount = await getBurnAmount(signer);
            setBurnAmount(amount);
        }
    };

    // Staking status
    const pauseHandler = async () => {
        if (signer) {
            const result = await pauseStaking(selectedStaking, signer);
            if (result) {
                alert("Successfully paused");
            } else {
                alert("Some error");
            }
        }
    };
    const unpauseHandler = async () => {
        if (signer) {
            const result = await unpauseStaking(selectedStaking, signer);
            if (result) {
                alert("Successfully unpaused");
            } else {
                alert("Some error");
            }
        }
    };
    const returnAllStakes = async () => {
        if (signer) {
            const result = await returnStakings(selectedStaking, signer);
            if (result) {
                alert("Returned successfully");
            } else {
                alert("Some error");
            }
        }
    };

    // Reward pool
    const increaseRewardPoolHandler = async () => {
        const amount = (document.getElementById("rewardAmount") as HTMLInputElement).value;

        if (signer && amount) {
            if(selectedStaking === 1) {
                const approve = await approveAmount(selectedStaking, signer, amount);
                if (!approve) {
                    alert("Approve failed");
                    return;
                }
            } else if(selectedStaking === 2) {
                const approve = await approveUsdt(signer, amount);
                if (!approve) {
                    alert("Approve failed");
                    return;
                }
            }

            const result = await increaseRewardPool(selectedStaking, signer, amount);
            if (result) {
                await updateRewardPool();
                alert("Successfully increased");
            } else {
                alert("Some error");
            }
        }
    };
    const decreaseRewardPoolHandler = async () => {
        const amount = (document.getElementById("rewardAmount") as HTMLInputElement).value;

        if (signer && amount) {
            const result = await decreaseRewardPool(selectedStaking, signer, amount);
            if (result) {
                await updateRewardPool();
                alert("Successfully decreased");
            } else {
                alert("Some error");
            }
        }
    };
    const updateRewardPool = async () => {
        if (signer) {
            const amount = await getRewardPoolAmount(selectedStaking, signer);
            setRewardPoolAmount(amount);
        }
    };

    // UseEffect
    useEffect(() => {
        updateBurnAmount();
        updateRewardPool();
    }, [selectedStaking]);

    return (
        <div className="tab-container">
            <div className="part right">
                <div className="wrap">
                    <p>Staking</p>
                    <button
                        className={"btn" + (selectedStaking === 1 ? " selected" : "")}
                        onClick={() => setSelectedStaking(1)}
                    >
                        1
                    </button>
                    <button
                        className={"btn" + (selectedStaking === 2 ? " selected" : "")}
                        onClick={() => setSelectedStaking(2)}
                    >
                        2
                    </button>
                </div>
            </div>
            <div className="part">
                <h3>Mint tokens:</h3>
                <div className="wrap">
                    <input className="input" type={"number"} id={"mintAmount"}></input>
                    <button className="btn" onClick={mintHandler}>
                        Mint
                    </button>
                </div>
            </div>
            <div className="part">
                <h3>Burn tokens: {burnAmount} BHC</h3>
                <div className="wrap">
                    <input className="input" type={"number"} id={"burnAmount"}></input>
                    <button className="btn" onClick={burnHandler}>
                        Burn
                    </button>
                </div>
            </div>
            <div className="part">
                <h3>Staking state:</h3>
                <div className="wrap">
                    <button className="btn" onClick={pauseHandler}>
                        Pause
                    </button>
                    <button className="btn" onClick={unpauseHandler}>
                        Unpause
                    </button>
                </div>
            </div>
            <div className="part">
                <h3>Return all stakes:</h3>
                <div className="wrap">
                    <button className="btn" onClick={returnAllStakes}>
                        Return
                    </button>
                </div>
            </div>
            <div className="part">
                <h3>Reward pool: {rewardPoolAmount} {(selectedStaking === 2) ? 'USDT' : 'BHC'}</h3>
                <div className="wrap">
                    <input className="input" type={"number"} id={"rewardAmount"}></input>
                    <button className="btn" onClick={increaseRewardPoolHandler}>
                        Increase
                    </button>
                    <button className="btn" onClick={decreaseRewardPoolHandler}>
                        Decrease
                    </button>
                </div>
            </div>
            <div className="part">
                <StakingsTable selectedStaking={selectedStaking} />
            </div>
        </div>
    );
};

export default Admin;
