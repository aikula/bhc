import "./Tab.scss";
import { useContext } from "react";
import { Context } from "../../../main";
import Text from "../../../languages.json";
import { observer } from "mobx-react";

import Image1 from "../../../assets/metamask.svg";
import Image2 from "../../../assets/ledger.svg";

const Help = observer(() => {
    const { language } = useContext(Context);

    return (
        <div className="tab-container help">
            <h2>{Text.help.heading[language]}</h2>
            <p>{Text.help.body.p1[language]}</p>
            <img src={Image1} alt={"metamask.svg"}></img>
            <p>{Text.help.body.p2[language]}</p>
            <img src={Image2} alt={"ledger.svg"}></img>
        </div>
    );
});

export default Help;
