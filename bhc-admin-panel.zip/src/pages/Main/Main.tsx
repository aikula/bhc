import "./Main.scss";
import { Route, Routes } from "react-router-dom";
import MainHeader from "../../components/Headers/MainHeader";
import Free from "./Tabs/Free";
import Help from "./Tabs/Help";
import Staking from "./Tabs/Staking";
import { observer } from "mobx-react";
import { RoutesConsts } from "../../helpers/Routes";
import NavigationSidebar from "../../components/NavigationSidebar/NavigationSidebar";
import { useContext, useEffect, useState } from "react";
import { Context } from "../../main";
import { useSigner } from "wagmi";
import Admin from "./Tabs/Admin";

const Main = observer(() => {
    const { isMobile, userStore} = useContext(Context);
    const { data: signer } = useSigner();
    const [isAdmin, setIsAdmin] = useState(false);

    useEffect(() => {
        if(signer) {
            const checkAdmin = async () => {
                if (signer && (await signer.getAddress()).toLowerCase() === import.meta.env.VITE_ADMIN_ADDRESS.toLowerCase()) {
                    setIsAdmin(true);
                } else {
                    setIsAdmin(false);
                }
            };
            checkAdmin();
            userStore.clear();
        }
    }, [signer]);

    return (
        <>
            <MainHeader />
            <main className="main-container">
                <div className="wrap">
                    {!isMobile && <NavigationSidebar />}

                    <Routes>
                        <Route path="/" element={<Staking />} />
                        <Route path={`${RoutesConsts.STAKING}/:index`} element={<Staking />} />
                        <Route path={`${RoutesConsts.FREE_TOKENS}`} element={<Free />} />
                        <Route path={RoutesConsts.HELP} element={<Help />} />
                        {isAdmin && <Route path={RoutesConsts.ADMIN} element={<Admin />} />}
                    </Routes>
                </div>
            </main>
        </>
    );
});

export default Main;
