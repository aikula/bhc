import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAccount } from "wagmi";
import "./App.scss";
import AppRouter from "./AppRouter";
import { RoutesConsts } from "./helpers/Routes";
import ConnectModal from "./modals/ConnectModal";

const App = () => {
    const {address} = useAccount();
    const navigate = useNavigate();

    useEffect(() => {
        if(address) {
            navigate(RoutesConsts.PANEL);
        } else {
            navigate(RoutesConsts.LANDING);
        }
    }, [address]);

    return (
        <div className="app-container">
            <ConnectModal />
            <AppRouter />
        </div>
    );
};

export default App;
