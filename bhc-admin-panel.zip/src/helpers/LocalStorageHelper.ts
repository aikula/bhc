const LANGUAGE_VAR = "selected_language"

export const getLocalLanguage = (): string | null => {
    return localStorage.getItem(LANGUAGE_VAR);
}
export const setLocalLanguage = (language: string) => {
    localStorage.setItem(LANGUAGE_VAR, language);
}