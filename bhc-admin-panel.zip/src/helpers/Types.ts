export enum Languages {
    EN = "en",
    RU = "ru",
    AR = "ar",
}

export type OperationType = {
    timestamp: number;
    type: OperationEnum;
    value: string;
};
export enum OperationEnum {
    deposit = "deposit",
    claim = "claim",
}

export type UserStake = {
    id: number;
    account: string;
    amount: string;
    closed: boolean;
    endAt: number;
    reward: string;
    startsAt: number;
};
