export enum RoutesConsts {
    LANDING = "/",
    PANEL = "panel",
    STAKING = "staking",
    FREE_TOKENS = "free",
    HELP = "help",
    ADMIN = "admin",
}
