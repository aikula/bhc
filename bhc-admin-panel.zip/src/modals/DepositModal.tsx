import "./Modal.scss";
import { useEffect, useRef, useState } from "react";
import { observer } from "mobx-react-lite";
import { useSigner } from "wagmi";
import { approveAmount } from "../API/TokenAPI";
import { stakeTokens } from "../API/ContractAPI";

enum DepositState {
    CAN_APPROVE,
    AWATING_APPROVE,
    CAN_DEPOSIT,
    AWAITING_DEPOSIT
}

type Props = {
    stakeNumber: number;
    modal: boolean;
    setModal: (modal: boolean) => void;
};

const DepositModal = observer(({ stakeNumber, modal, setModal }: Props) => {
    const modalContainer = useRef<HTMLDivElement>(null);
    const { data: signer } = useSigner();
    const [state, setState] = useState(DepositState.CAN_APPROVE);
    const [depositAmount, setDepositAmount] = useState("0");

    const handleClose = (e: any) => {
        if (e.target.className === "modal_container") {
            setModal(false);
        }
    };

    const approveHandler = async () => {
        if (signer && state === DepositState.CAN_APPROVE) {
            const amount = (document.getElementById("depositAmount") as HTMLInputElement).value;

            if (amount) {
                setDepositAmount(amount);
                setState(DepositState.AWATING_APPROVE);
                const approveResult = await approveAmount(stakeNumber, signer, amount);
                if (approveResult) {
                    alert("Approved successfully");
                    setState(DepositState.CAN_DEPOSIT);
                } else {
                    alert("Approve failed");
                    setState(DepositState.CAN_APPROVE);
                }
            } else {
                alert("Enter value");
            }
        }
    };

    const depositHandler = async () => {
        if (signer && state === DepositState.CAN_DEPOSIT) {
            setState(DepositState.AWAITING_DEPOSIT);
            const stakeResult = await stakeTokens(stakeNumber, signer, depositAmount);
            if (stakeResult) {
                alert("Successfully staked");
                setState(DepositState.CAN_APPROVE);
                setModal(false);
            } else {
                alert("Stake failed");
                setState(DepositState.CAN_DEPOSIT);
            }
        }
    };

    useEffect(() => {
        if (modalContainer.current) {
            const container = modalContainer.current;

            if (modal === true) {
                container.style.display = "flex";
                setTimeout(() => {
                    container.classList.remove("hidden");
                }, 100);
            } else {
                container.classList.add("hidden");
                setTimeout(() => {
                    container.style.display = "none";
                }, 400);
            }
        }
    }, [modal]);

    return (
        <div
            className={"modal_container deposit_modal"}
            style={{ display: "none" }}
            onClick={(e) => handleClose(e)}
            ref={modalContainer}
        >
            <div className="modal_window">
                <button className="close_btn" onClick={() => setModal(false)}>
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1L17 17" stroke="#383838" />
                        <path d="M17 1L1 17" stroke="#383838" />
                    </svg>
                </button>
                <div className="body_wrap">
                    <h3>Deposit:</h3>
                    <input className="input" type={"number"} id="depositAmount"></input>
                    <button
                        className={"btn" + (state !== DepositState.CAN_APPROVE ? " disabled" : "")}
                        onClick={approveHandler}
                    >
                        Approve
                    </button>
                    <button
                        className={"btn" + (state !== DepositState.CAN_DEPOSIT ? " disabled" : "")}
                        onClick={depositHandler}
                    >
                        Deposit
                    </button>
                </div>
            </div>
        </div>
    );
});

export default DepositModal;
