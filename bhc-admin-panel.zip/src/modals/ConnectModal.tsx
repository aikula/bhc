import "./Modal.scss";
import { useContext, useEffect, useRef } from "react";
import MetamaskIcon from "./../Assets/metamask.svg";
import WalletConnectIcon from "./../Assets/walletConnect.svg";
import LedgerIcon from "./../Assets/ledger.svg";
import { ethers } from "ethers";
import { Context } from "../main";
import { observer } from "mobx-react-lite";
import { useConnect } from "wagmi";

const ConnectModal = observer(() => {
    const { connect, connectors } = useConnect();
    const modalContainer = useRef<HTMLDivElement>(null);
    const { connectModal: modal, setConnectModal: setModal } = useContext(Context);

    // Metamask
    const connectMetamaskWallet = async () => {
        try {
            const chainId = await window.ethereum.request({
                method: "eth_chainId",
            });
            const chainNumber = ethers.BigNumber.from(chainId).toString();

            if (import.meta.env.VITE_CHAIN_ID && chainNumber !== import.meta.env.VITE_CHAIN_ID.toString()) {
                try {
                    await window.ethereum.request({
                        method: "wallet_switchEthereumChain",
                        params: [
                            {
                                chainId: ethers.utils.hexValue(parseInt(import.meta.env.VITE_CHAIN_ID)),
                            },
                        ],
                    });
                } catch (e: any) {
                    console.log(e.message);
                    return;
                }
            }
            connect({ connector: connectors[0] });
            setModal(false);
        } catch (e: any) {
            console.log(e.message);
        }
    };

    // WalletConnect
    const connectWalletConnect = async () => {
        try {
            connect({ connector: connectors[1] });
            setModal(false);
        } catch (e: any) {
            console.log(e.message);
        }
    };

    // Ledger
    const connectLedger = async () => {
        try {
            connect({ connector: connectors[2] })
            setModal(false);
        } catch(e: any) {
            console.log(e.message);
        }
    }

    const handleClose = (e: any) => {
        if (e.target.className === "modal_container") {
            setModal(false);
        }
    };

    useEffect(() => {
        if (modalContainer.current) {
            const container = modalContainer.current;

            if (modal === true) {
                container.style.display = "flex";
                setTimeout(() => {
                    container.classList.remove("hidden");
                }, 100);
            } else {
                container.classList.add("hidden");
                setTimeout(() => {
                    container.style.display = "none";
                }, 400);
            }
        }
    }, [modal]);

    return (
        <div
            className={"modal_container"}
            style={{ display: "none" }}
            onClick={(e) => handleClose(e)}
            ref={modalContainer}
        >
            <div className="modal_window">
                <button className="close_btn" onClick={() => setModal(false)}>
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1L17 17" stroke="#383838" />
                        <path d="M17 1L1 17" stroke="#383838" />
                    </svg>
                </button>
                <div className="wallet_type" onClick={connectMetamaskWallet}>
                    <img src={MetamaskIcon} alt={"metamask.svg"}></img>
                    <h2>MetaMask</h2>
                    <p>Connect to the provider in your browser</p>
                </div>
                <hr />
                <div className="wallet_type" onClick={connectWalletConnect}>
                    <img src={WalletConnectIcon} alt={"walletConnect.svg"}></img>
                    <h2>WalletConnect</h2>
                    <p>Scan with WalletConnect to connect</p>
                </div>
                <hr />
                <div className="wallet_type" onClick={connectLedger}>
                    <img src={LedgerIcon} alt={"ledger.svg"}></img>
                    <h2>Ledger</h2>
                    <p>Connect your cold wallet with ledger live</p>
                </div>
            </div>
        </div>
    );
});

export default ConnectModal;
