import { Route, Routes } from "react-router-dom";
import { RoutesConsts } from "./helpers/Routes";
import Landing from "./pages/Landing/Landing";
import Main from "./pages/Main/Main";
import NotFound from "./pages/NotFound/NotFound";

const AppRouter = () => {
    return (
        <Routes>
            <Route path={RoutesConsts.LANDING} element={<Landing />}></Route>
            <Route path={`/${RoutesConsts.PANEL}/*`} element={<Main />}></Route>
            <Route path="*" element={<NotFound />}></Route>
        </Routes>
    );
};

export default AppRouter;
