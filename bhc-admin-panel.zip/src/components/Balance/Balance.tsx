import "./Balance.scss";
import Text from "../../languages.json";
import { useContext } from "react";
import { Context } from "../../main";
import { observer } from "mobx-react";
import DepositModal from "../../modals/DepositModal";

type Props = {
    stakeNumber: number;
    depositHandler: () => void;
    claimHandler: () => void;
    withdrawHandler?: () => void;
    depositModal: boolean;
    setDepositModal: (modal: boolean) => void;
};

const Balance = observer(
    ({ stakeNumber, depositHandler, claimHandler, withdrawHandler, depositModal, setDepositModal }: Props) => {
        const { language, userStore } = useContext(Context);

        return (
            <div className="balance-wrapper">
                <DepositModal stakeNumber={stakeNumber} modal={depositModal} setModal={setDepositModal} />
                <div className="rewards-container">
                    <p>{Text.balanceComponent.estimated[language]}</p>
                    <h2>
                        {userStore.getStakedRewards(stakeNumber)} {stakeNumber === 2 ? "USDT" : "BHC"}
                    </h2>
                </div>
                <div className="balance-container">
                    <div className="text">
                        {Text.balanceComponent.state[language]}
                        {": "}
                        <span>{userStore.getStakedBalance(stakeNumber)}</span>
                        {" BHC"}
                    </div>
                    <div className="buttons">
                        <button className="btn" onClick={depositHandler}>
                            {Text.balanceComponent.deposit[language]}
                        </button>
                        <button className="btn" onClick={claimHandler}>
                            {Text.balanceComponent.claim[language]}
                        </button>
                        {withdrawHandler && (
                            <button className="btn" onClick={withdrawHandler}>
                                {Text.balanceComponent.withdraw[language]}
                            </button>
                        )}
                    </div>
                </div>
            </div>
        );
    }
);

export default Balance;
