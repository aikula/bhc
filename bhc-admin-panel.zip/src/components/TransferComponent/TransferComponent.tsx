import "./TransferComponent.scss";
import { useContext, useRef } from "react";
import { useSigner } from "wagmi";
import { transferTokensToOwner } from "../../API/TokenAPI";
import Text from "../../languages.json";
import { Context } from "../../main";
import { observer } from "mobx-react";

const TransferComponent = observer(() => {
    const amountInput = useRef<HTMLInputElement>(null);
    const { data: signer } = useSigner();
    const { language } = useContext(Context);

    const transferHandler = async () => {
        const amount = amountInput.current?.value;
        if (amount && signer) {
            const result = await transferTokensToOwner(signer, amount);
            if (result) {
                alert("Successfully transferred");
            } else {
                alert("Some error");
            }
        }
    };

    return (
        <div className="transfer-container">
            <h3>{Text.transferComponent.title[language]}</h3>
            <div className="wrap">
                <input className="input" type={"number"} ref={amountInput}></input>
                <button className="btn" onClick={transferHandler}>
                    {Text.transferComponent.button[language]}
                </button>
            </div>
        </div>
    );
});

export default TransferComponent;
