import "./OperationHistory.scss";
import Text from "../../languages.json";
import { useContext } from "react";
import { Context } from "../../main";
import { observer } from "mobx-react-lite";
import { OperationEnum } from "../../helpers/Types";

type Props = {
    stakeNumber: number;
}

const OperationHistory = observer(({stakeNumber}: Props) => {
    const { language, userStore } = useContext(Context);

    return (
        <div className="operations-container">
            <h3>{Text.operations.heading[language]}</h3>
            <div className="operations-wrapper">
                {userStore.getOperationsHostory(stakeNumber).map((operation, index) => {
                    return (
                        <div className="operation" key={index}>
                            {new Date(operation.timestamp).toLocaleDateString()} - {" "}
                            {Text.operations.types[operation.type][language]} {" "}
                            {operation.value} {stakeNumber === 2 && operation.type === OperationEnum.claim ? "USDT" : "BHC"}
                        </div>
                    );
                })}
            </div>
        </div>
    );
});

export default OperationHistory;
