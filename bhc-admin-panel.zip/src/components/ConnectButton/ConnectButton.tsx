import { useContext, useEffect } from "react";
import { Context } from "../../main";
import "./ConnectButton.scss";
import Text from "../../languages.json";
import { useAccount, useDisconnect } from "wagmi";
import { shortAddress } from "../../helpers/Helpers";

type Props = {
    styles?: Object;
};

const ConnectButton = ({ styles }: Props) => {
    const { language, setConnectModal } = useContext(Context);
    const { address } = useAccount();
    const { disconnect } = useDisconnect();

    const connectHandler = () => {
        setConnectModal(true);
    };

    const disconnectHandler = () => {
        disconnect();
    };

    return (
        <div className="connect-button-container">
            {address ? (
                <button className="btn connected" style={styles} onClick={disconnectHandler}>
                    {shortAddress(address)}
                </button>
            ) : (
                <button className="btn" style={styles} onClick={connectHandler}>
                    {Text.buttons.connectButton[language]}
                </button>
            )}
        </div>
    );
};

export default ConnectButton;
