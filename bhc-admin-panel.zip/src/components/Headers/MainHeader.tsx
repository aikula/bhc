import { observer } from "mobx-react";
import { useContext, useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { Context } from "../../main";
import ConnectButton from "../ConnectButton/ConnectButton";
import LanguageSelector from "../LanguageSelector/LanguageSelector";
import NavigationSidebar from "../NavigationSidebar/NavigationSidebar";
import "./Header.scss";

const MainHeader = observer(() => {
    const params = useParams();
    const { isMobile } = useContext(Context);
    const [isOpened, setIsOpened] = useState(false);
    const burgerContainer = useRef<HTMLDivElement>(null);

    const closeBurger = () => {
        setIsOpened(false);
        setTimeout(() => {
            burgerContainer.current?.classList.add("hidden");
            document.querySelector("body")?.classList.remove("fixed");
        }, 500);
    };
    const openBurger = () => {
        burgerContainer.current?.classList.remove("hidden");
        document.querySelector("body")?.classList.add("fixed");
        setTimeout(() => {
            setIsOpened(true);
        }, 50);
    };
    const handleBurger = () => {
        if (isOpened) {
            closeBurger();
        } else {
            openBurger();
        }
    };

    useEffect(() => {
        closeBurger();
    }, [params]);

    useEffect(() => {
        if (isMobile) {
            burgerContainer.current?.classList.add("hidden");
        }
    }, [isMobile]);

    return (
        <header className="header-container">
            {/* Header strip */}
            <h1>LOGO</h1>
            {isMobile ? (
                <>
                    <div className="wrap">
                        <ConnectButton />
                        {/* Menu button */}
                        <div className="burger-button" onClick={handleBurger}>
                            {isOpened ? (
                                <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M13.41 12L17.71 7.71C17.8983 7.5217 18.0041 7.2663 18.0041 7C18.0041 6.7337 17.8983 6.47831 17.71 6.29C17.5217 6.1017 17.2663 5.99591 17 5.99591C16.7337 5.99591 16.4783 6.1017 16.29 6.29L12 10.59L7.71 6.29C7.5217 6.1017 7.2663 5.99591 7 5.99591C6.7337 5.99591 6.4783 6.1017 6.29 6.29C6.1017 6.47831 5.99591 6.7337 5.99591 7C5.99591 7.2663 6.1017 7.5217 6.29 7.71L10.59 12L6.29 16.29C6.19627 16.383 6.12188 16.4936 6.07111 16.6154C6.02034 16.7373 5.9942 16.868 5.9942 17C5.9942 17.132 6.02034 17.2627 6.07111 17.3846C6.12188 17.5064 6.19627 17.617 6.29 17.71C6.38296 17.8037 6.49356 17.8781 6.61542 17.9289C6.73728 17.9797 6.86799 18.0058 7 18.0058C7.13201 18.0058 7.26272 17.9797 7.38458 17.9289C7.50644 17.8781 7.61704 17.8037 7.71 17.71L12 13.41L16.29 17.71C16.383 17.8037 16.4936 17.8781 16.6154 17.9289C16.7373 17.9797 16.868 18.0058 17 18.0058C17.132 18.0058 17.2627 17.9797 17.3846 17.9289C17.5064 17.8781 17.617 17.8037 17.71 17.71C17.8037 17.617 17.8781 17.5064 17.9289 17.3846C17.9797 17.2627 18.0058 17.132 18.0058 17C18.0058 16.868 17.9797 16.7373 17.9289 16.6154C17.8781 16.4936 17.8037 16.383 17.71 16.29L13.41 12Z"
                                        fill="#1F0545"
                                    />
                                </svg>
                            ) : (
                                <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M20.05 11H3.95C3.42533 11 3 11.4253 3 11.95V12.05C3 12.5747 3.42533 13 3.95 13H20.05C20.5747 13 21 12.5747 21 12.05V11.95C21 11.4253 20.5747 11 20.05 11Z"
                                        fill="#1F0545"
                                    />
                                    <path
                                        d="M20.05 16H3.95C3.42533 16 3 16.4253 3 16.95V17.05C3 17.5747 3.42533 18 3.95 18H20.05C20.5747 18 21 17.5747 21 17.05V16.95C21 16.4253 20.5747 16 20.05 16Z"
                                        fill="#1F0545"
                                    />
                                    <path
                                        d="M20.05 6H3.95C3.42533 6 3 6.42533 3 6.95V7.05C3 7.57467 3.42533 8 3.95 8H20.05C20.5747 8 21 7.57467 21 7.05V6.95C21 6.42533 20.5747 6 20.05 6Z"
                                        fill="#1F0545"
                                    />
                                </svg>
                            )}
                        </div>
                    </div>
                    {/* Burger menu */}
                    <div className={"burger-container" + (isOpened ? " opened" : "")} ref={burgerContainer}>
                        <NavigationSidebar />
                        <LanguageSelector />
                    </div>
                </>
            ) : (
                <div className="wrap">
                    <LanguageSelector />
                    <ConnectButton />
                </div>
            )}
        </header>
    );
});

export default MainHeader;
