import LanguageSelector from "../LanguageSelector/LanguageSelector";
import "./Header.scss";

const LandingHeader = () => {
    return(
        <header className="header-container">
            <h1>LOGO</h1>
            <LanguageSelector />
        </header>
    );
}

export default LandingHeader;