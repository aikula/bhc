import "./StakingsTable.scss";
import Text from "../../languages.json";
import { observer } from "mobx-react";
import { useContext, useEffect, useState } from "react";
import { Context } from "../../main";
import { UserStake } from "../../helpers/Types";
import { useSigner } from "wagmi";
import { getAllStakesByPage } from "../../API/ContractAPI";
import { shortAddress } from "../../helpers/Helpers";
import ReactPaginate from "react-paginate";

type Props = {
    selectedStaking: number;
};

const StakingsTable = observer(({ selectedStaking }: Props) => {
    const { language, isMobile } = useContext(Context);
    const { data: signer } = useSigner();
    const [stakings, setStakings] = useState<UserStake[] | null>(null);
    const [pageNumber, setPageNumber] = useState(1);
    const [maxPages, setMaxPages] = useState(1);

    const getStakings = async (page: number) => {
        if (signer) {
            const { stakes, totalPages } = await getAllStakesByPage(selectedStaking, signer, page);
            setStakings(stakes);
            setMaxPages(totalPages);
        }
    };

    const handlePageClick = (event: any) => {
        setPageNumber(event.selected + 1);
        getStakings(event.selected + 1);
    };

    useEffect(() => {
        if(stakings) {
            getStakings(1);
            setPageNumber(1);
        }
    }, [selectedStaking]);

    return (
        <div className="stakings-container">
            <h3>{Text.stakingsTable.heading[language]}</h3>
            <table>
                <thead>
                    <tr>
                        <th>Address</th>
                        <th>Date</th>
                        <th>State</th>
                        <th>Ended</th>
                        <th>{!isMobile ? "Amount" : "Amt"}</th>
                        <th>{!isMobile ? "Reward" : "Rwd"}</th>
                    </tr>
                </thead>
                <tbody>
                    {stakings?.map((stake, index) => {
                        return (
                            <tr className="stake" key={index}>
                                <td>{shortAddress(stake.account)}</td>
                                <td>{new Date(stake.startsAt).toLocaleDateString()}</td>
                                <td>{stake.closed ? "Closed" : "Opened"}</td>
                                <td>{stake.endAt === 0 ? "None" : new Date(stake.endAt).toLocaleDateString()}</td>
                                <td>
                                    {stake.amount}
                                    {!isMobile ? ((selectedStaking === 2) ? " USDT" : " BHC") : ""}
                                </td>
                                <td>
                                    {stake.reward}
                                    {!isMobile ? ((selectedStaking === 2) ? " USDT" : " BHC") : ""}
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
            <ReactPaginate
                className={"pages-container"}
                breakLabel="..."
                nextLabel=">"
                onPageChange={handlePageClick}
                pageRangeDisplayed={5}
                pageCount={maxPages}
                previousLabel="<"
                initialPage={pageNumber - 1}
                forcePage={pageNumber - 1}
            />
        </div>
    );
});

export default StakingsTable;
