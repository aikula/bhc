import "./StakingsTable.scss";
import Text from "../../languages.json";
import { observer } from "mobx-react";
import { useContext } from "react";
import { Context } from "../../main";

type Props = {
    stakeNumber: number;
    closeStaking: (id: number) => void;
};

const UserStakingsTable = observer(({ stakeNumber, closeStaking }: Props) => {
    const { language, userStore } = useContext(Context);

    return (
        <div className="stakings-container mt">
            <h3>{Text.userStakingsTable.heading[language]}</h3>
            {userStore.getStakes(stakeNumber).length === 0 ? (
                <p>{Text.userStakingsTable.noStakes[language]}</p>
            ) : (
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Amount</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {userStore.getStakes(stakeNumber).map((stake, index) => {
                            return (
                                <tr className="stake" key={index}>
                                    <td>{new Date(stake.startsAt).toLocaleDateString()}</td>
                                    <td>{stake.amount} BHC</td>
                                    <td className="right">
                                        <button className={"btn"} onClick={() => closeStaking(stake.id)}>
                                            Close
                                        </button>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            )}
        </div>
    );
});

export default UserStakingsTable;
