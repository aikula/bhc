import "./NavigationSidebar.scss";
import { Link, useParams } from "react-router-dom";
import Text from "../../languages.json";
import { useContext, useEffect, useState } from "react";
import { Context } from "../../main";
import { RoutesConsts } from "../../helpers/Routes";
import { observer } from "mobx-react";
import { useSigner } from "wagmi";

const NavigationSidebar = observer(() => {
    const params = useParams();
    const { language } = useContext(Context);
    const { data: signer } = useSigner();
    const [isAdmin, setIsAdmin] = useState(false);

    useEffect(() => {
        const checkAdmin = async () => {
            if (signer && (await signer.getAddress()).toLowerCase() === import.meta.env.VITE_ADMIN_ADDRESS.toLowerCase()) {
                setIsAdmin(true);
            } else {
                setIsAdmin(false);
            }
        };
        checkAdmin();
    }, [signer]);

    return (
        <nav className="sidebar-container">
            <Link
                to={`${RoutesConsts.STAKING}/1`}
                className={
                    "link" + (params["*"] === `${RoutesConsts.STAKING}/1` || params["*"] === "" ? " selected" : "")
                }
            >
                {Text.leftSidebar.staking[language]} 1
            </Link>
            <Link
                to={`${RoutesConsts.STAKING}/2`}
                className={"link" + (params["*"] === `${RoutesConsts.STAKING}/2` ? " selected" : "")}
            >
                {Text.leftSidebar.staking[language]} 2
            </Link>
            <Link
                to={`${RoutesConsts.FREE_TOKENS}`}
                className={"link" + (params["*"] === `${RoutesConsts.FREE_TOKENS}` ? " selected" : "")}
            >
                {Text.leftSidebar.free[language]}
            </Link>
            {isAdmin && (
                <Link
                    to={`${RoutesConsts.ADMIN}`}
                    className={"link" + (params["*"] === `${RoutesConsts.ADMIN}` ? " selected" : "")}
                >
                    {Text.leftSidebar.admin[language]}
                </Link>
            )}
            <hr></hr>
            <Link to={RoutesConsts.HELP} className={"link" + (params["*"] === RoutesConsts.HELP ? " selected" : "")}>
                {Text.leftSidebar.help[language]}
            </Link>
        </nav>
    );
});

export default NavigationSidebar;
