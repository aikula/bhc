import { observer } from "mobx-react";
import { useContext } from "react";
import { setLocalLanguage } from "../../helpers/LocalStorageHelper";
import { Context } from "../../main";
import { Languages } from "../../store/RootStore";
import "./LanguageSelector.scss";

const LanguageSelector = observer(() => {
  const {language, setLanguage} = useContext(Context);

  const changeLanguage = (ln: string) => {
    setLanguage(ln);
    setLocalLanguage(ln);
  };

  return (
    <div className="language-selector-container">
      <div
        onClick={() => changeLanguage(Languages.EN)}
        className={"language" + (language === Languages.EN ? " selected" : "")}
      >
        En
      </div>
      <span>/</span>
      <div
        onClick={() => changeLanguage(Languages.RU)}
        className={"language" + (language === Languages.RU ? " selected" : "")}
      >
        Ru
      </div>
      <span>/</span>
      <div
        onClick={() => changeLanguage(Languages.AR)}
        className={"language" + (language === Languages.AR ? " selected" : "")}
      >
        Ar
      </div>
    </div>
  );
});

export default LanguageSelector;
