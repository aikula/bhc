import { createContext } from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { RootStore } from "./store/RootStore";
import "./index.scss";

import { WagmiConfig, createClient, configureChains } from "wagmi";
import { mainnet, goerli } from "wagmi/chains";
import { jsonRpcProvider } from "wagmi/providers/jsonRpc";
import { InjectedConnector } from "wagmi/connectors/injected";
import { WalletConnectConnector } from "wagmi/connectors/walletConnect";
import { LedgerConnector } from "wagmi/connectors/ledger";

// Creating context
export const Context = createContext<RootStore>({} as RootStore);

// Configurating chains
const { chains, provider, webSocketProvider } = configureChains(
    [import.meta.env.VITE_CHAIN_ID === "1" ? mainnet : goerli],
    [
        jsonRpcProvider({
            rpc: (chain) => ({
                http: import.meta.env.VITE_NODE_URL,
            }),
        }),
    ]
);

// Configurating client
const client = createClient({
    autoConnect: true,
    connectors: [
        new InjectedConnector({
            chains,
            options: { name: "Injected" },
        }),
        new WalletConnectConnector({
            chains,
            options: {
                name: "Walletconnect",
                qrcode: true,
            },
        }),
        new LedgerConnector({
            chains,
        }),
    ],
    provider,
    webSocketProvider,
});

// Building DOM
ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
    <Context.Provider value={new RootStore()}>
        <WagmiConfig client={client}>
            <BrowserRouter>
                <App />
            </BrowserRouter>
        </WagmiConfig>
    </Context.Provider>
);
