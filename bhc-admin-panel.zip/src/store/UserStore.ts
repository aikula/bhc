import { makeAutoObservable } from "mobx";
import { OperationType, UserStake } from "../helpers/Types";

export class UserStore {
    private _balance: string;
    private _stakedBalances: {1: string, 2: string};
    private _stakedRewards: {1: string, 2: string};
    private _stakes: {1: UserStake[], 2: UserStake[]};
    private _operationsHistories: {1: OperationType[], 2: OperationType[]};

    constructor() {
        this._balance = "0";
        this._stakedBalances = {1: "0", 2: "0"};
        this._stakedRewards = {1: "0", 2: "0"};
        this._stakes = {1: [], 2: []};
        this._operationsHistories = {1: [], 2: []};
        makeAutoObservable(this);
    }

    setBalance = (balance: string): void => {
        this._balance = balance;
    }
    get balance(): string {
        return this._balance;
    }

    setStakedBalance = (stake: number, balance: string) => {
        type ObjectKey = keyof typeof this._stakedBalances;
        this._stakedBalances[stake as ObjectKey] = balance;
    }
    getStakedBalance = (stake: number): string => {
        type ObjectKey = keyof typeof this._stakedBalances;
        return this._stakedBalances[stake as ObjectKey];
    }

    setStakedRewards = (stake: number, reward: string) => {
        type ObjectKey = keyof typeof this._stakedRewards;
        this._stakedRewards[stake as ObjectKey] = reward;
    }
    getStakedRewards = (stake: number): string => {
        type ObjectKey = keyof typeof this._stakedRewards;
        return this._stakedRewards[stake as ObjectKey];
    }

    setOperationsHistory = (stake: number, operations: OperationType[]) => {
        type ObjectKey = keyof typeof this._operationsHistories;
        this._operationsHistories[stake as ObjectKey] = operations;
    }
    getOperationsHostory = (stake: number): OperationType[] => {
        type ObjectKey = keyof typeof this._operationsHistories;
        return this._operationsHistories[stake as ObjectKey];
    }

    setStakes = (stake: number, stakes: UserStake[]) => {
        type ObjectKey = keyof typeof this._stakes;
        this._stakes[stake as ObjectKey] = stakes;
    }
    getStakes = (stake: number): UserStake[] => {
        type ObjectKey = keyof typeof this._stakes;
        return this._stakes[stake as ObjectKey];
    }

    clear = (): void => {
        this._balance = "0";
        this._stakedBalances = {1: "0", 2: "0"};
        this._operationsHistories = {1: [], 2: []};
    }
}