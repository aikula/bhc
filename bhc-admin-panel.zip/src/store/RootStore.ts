import { makeAutoObservable } from "mobx";
import { getLocalLanguage } from "../helpers/LocalStorageHelper";
import { Languages } from "../helpers/Types";
import { UserStore } from "./UserStore";

export class RootStore {
    userStore: UserStore;
    private _language: Languages;
    private _connectModal: boolean;
    private _isMobile: boolean;

    constructor() {
        this.userStore = new UserStore();
        const localLanguage = getLocalLanguage();
        this._language = (localLanguage as Languages) ?? Languages.EN;
        this._connectModal = false;
        this._isMobile = false;
        this.resizeHandler();
        window.addEventListener('resize', this.resizeHandler);
        makeAutoObservable(this);
    }

    setLanguage = (ln: string) => {
        this._language = ln as Languages;
    };
    get language(): Languages {
        return this._language;
    }

    setConnectModal = (state: boolean) => {
        this._connectModal = state;
    };
    get connectModal(): boolean {
        return this._connectModal;
    }

    resizeHandler = () => {
        if (window.innerWidth < 751) {
            this.setIsMobile(true);
        } else {
            this.setIsMobile(false);
        }
    };
    setIsMobile = (isMobile: boolean): void => {
        this._isMobile = isMobile;
    }
    get isMobile(): boolean {
        return this._isMobile;
    }
}

export { Languages };
